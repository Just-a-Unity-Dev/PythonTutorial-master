x = 1

if x==1:
	print('x is equal to 1!')
else:
	print('x is not equal to 1...')