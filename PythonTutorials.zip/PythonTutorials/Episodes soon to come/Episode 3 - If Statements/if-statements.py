x = 1

if x==1:
	print('x is equal to 1!')