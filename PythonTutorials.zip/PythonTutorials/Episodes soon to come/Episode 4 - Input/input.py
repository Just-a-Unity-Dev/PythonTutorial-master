print('Hey there! Whats your name?')
x = input()
print('Hi there ' + x + " !")