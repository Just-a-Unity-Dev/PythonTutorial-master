suspects = ['Brock', 'Mack', 'Zonk']
criminal_name='Brock'

if suspects[0]==criminal_name:
	print(suspects[0] + ' was the thief!')