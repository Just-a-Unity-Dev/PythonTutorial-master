prisoners = ['jack', 'brock', 'red']

print(prisoners[0-2])