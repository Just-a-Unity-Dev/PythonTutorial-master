suspects = ['Jack', 'Mack', 'Brawn', 'Brain']

print('Choose a suspect to sentence to Jail.')
for i in range(4):
	print(suspects[i])
	i + 1
x = input()

if x == 'Jack':
	print('You sentenced suspect Jack!')
x=input()