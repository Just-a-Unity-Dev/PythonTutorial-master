# Variables store data! To create a variable, simply do
x = 1

# You can also print values!
print(x)