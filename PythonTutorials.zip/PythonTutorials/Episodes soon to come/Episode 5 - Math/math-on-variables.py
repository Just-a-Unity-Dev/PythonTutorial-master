x = 1
y = 5

print(x+y)