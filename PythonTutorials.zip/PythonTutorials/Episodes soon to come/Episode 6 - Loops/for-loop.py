for i in range(6):
	print(i)
	i + 1
else:
	print('done!')