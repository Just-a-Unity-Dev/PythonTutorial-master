#  Just do print("Hello, world!")
#  It is that easy!
print('Hello, world!')